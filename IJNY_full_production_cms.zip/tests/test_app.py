import os
os.environ['DATABASE_URL']='sqlite://'
os.environ['SECRET_KEY']='test-secret'
from app import create_app
def test_routes():
    app=create_app(); c=app.test_client()
    assert c.get('/').status_code==200
    assert c.get('/section/press').status_code==200
    assert c.get('/opportunities').status_code==200
    assert c.get('/resources').status_code==200
    assert c.get('/search?q=test').status_code==200
    assert c.get('/auth/login').status_code==200
    assert c.get('/control/').status_code==302
def test_security_upload():
    app=create_app(); c=app.test_client()
    assert c.get('/control/media').status_code==302
