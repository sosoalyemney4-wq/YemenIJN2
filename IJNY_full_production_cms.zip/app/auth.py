from flask import Blueprint,render_template,redirect,url_for,request,flash
from flask_login import login_user,logout_user,current_user,login_required
from datetime import datetime
from .models import User
from . import db
from . import limiter
auth_bp=Blueprint('auth',__name__,url_prefix='/auth')
@auth_bp.route('/login',methods=['GET','POST'])
@limiter.limit('10 per minute')
def login():
    if current_user.is_authenticated:return redirect(url_for('admin.dashboard'))
    if request.method=='POST':
        u=User.query.filter_by(email=request.form.get('email','').lower().strip()).first()
        if u and u.active and u.check_password(request.form.get('password','')): u.last_login=datetime.utcnow();db.session.commit();login_user(u,remember=bool(request.form.get('remember')));return redirect(url_for('admin.dashboard'))
        flash('بيانات الدخول غير صحيحة')
    return render_template('login.html')
@auth_bp.post('/logout')
@login_required
def logout(): logout_user();return redirect(url_for('main.home'))
@auth_bp.route('/password',methods=['GET','POST'])
@login_required
def password():
    if request.method=='POST':
        if not current_user.check_password(request.form['old']): flash('كلمة المرور الحالية غير صحيحة')
        elif len(request.form['new'])<10: flash('كلمة المرور الجديدة يجب ألا تقل عن 10 أحرف')
        else: current_user.set_password(request.form['new']);current_user.must_change_password=False;db.session.commit();flash('تم تغيير كلمة المرور');return redirect(url_for('admin.dashboard'))
    return render_template('admin/password.html')
